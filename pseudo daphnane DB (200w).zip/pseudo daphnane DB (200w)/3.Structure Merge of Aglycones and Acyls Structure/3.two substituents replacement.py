import pandas as pd

# paths
input_path1 = 'C:/Users/zhang/Desktop/Structure/MD_1Re_18.xlsx'
input_path2 = 'C:/Users/zhang/Desktop/Structure/Acyl-MD-18.xlsx'
output_path1 = 'C:/Users/zhang/Desktop/Structure/MD_2Re_18_7d.xlsx'

# Excel
df_skeleton = pd.read_excel(input_path1)
df_acyl = pd.read_excel(input_path2)

# Filter out rows containing only *sevend*
df_skeleton_filtered = df_skeleton[df_skeleton['New SMILES'].str.contains('\*sevend\*')]

result_rows = []
seen_combinations = set()

for _, skeleton_row in df_skeleton_filtered.iterrows():
    skeleton_smiles = skeleton_row['New SMILES']

    # Skeleton combination
    abcm_combination = (skeleton_row['A parts'], skeleton_row['B parts'], skeleton_row['C parts'], skeleton_row['Macro parts'])

    for _, acyl_row in df_acyl.iterrows():
        r1 = skeleton_row['R1 parts']
        r2 = acyl_row['R2 parts']
        substitution_pair = (r1, r2)
        reversed_pair = (r2, r1)

        combination_key = (abcm_combination, substitution_pair)
        reversed_combination_key = (abcm_combination, reversed_pair)

        if combination_key not in seen_combinations and reversed_combination_key not in seen_combinations:
            seen_combinations.add(combination_key)

            new_smiles = skeleton_smiles.replace('*sevend*', acyl_row['Acyl SMILES2'])
            result_row = skeleton_row.copy()
            result_row['New SMILES'] = new_smiles
            result_row['R2 parts'] = r2
            result_row['Acyl Formula 2'] = acyl_row['Acyl Formula 2']

            result_rows.append(result_row)

# Convert to DataFrame and save
result_df = pd.DataFrame(result_rows)
result_df.to_excel(output_path1, index=False)