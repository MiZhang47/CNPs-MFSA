import pandas as pd

# path
input_path1 = 'C:/Users/zhang/Desktop/Structure/MD_skeleton.xlsx'
input_path2 = 'C:/Users/zhang/Desktop/Structure/Acyl-MD.xlsx'
output_path1 = 'C:/Users/zhang/Desktop/Structure/MD_1Re_12.xlsx'

# Excel
df_skeleton = pd.read_excel(input_path1)
df_acyl = pd.read_excel(input_path2)

print(df_acyl.columns)

result_rows = []

for _, skeleton_row in df_skeleton.iterrows():
    skeleton_smiles = skeleton_row['New SMILES']
    # If there is a *** that needs to be replaced
    if '*twelve*' in skeleton_smiles:
        for _, acyl_row in df_acyl.iterrows():
            # *** replaced
            new_smiles = skeleton_smiles.replace('*twelve*', acyl_row['Acyl SMILES2'])
            # Add a new line to the result list, including the original information and the newly added Acyl information
            result_row = skeleton_row.copy()
            result_row['New SMILES'] = new_smiles
            result_row['R1 parts'] = acyl_row['R1 parts']
            result_row['Acyl Formula'] = acyl_row['Acyl Formula']
            result_rows.append(result_row)
    else:
        # If there is no *** that needs to be replaced, just add the original line to the result list
        result_rows.append(skeleton_row)

# Convert the resulting list to a DataFrame
result_df = pd.DataFrame(result_rows)

# Ensure all newly added columns are in the resulting DataFrame
if 'R1 parts' not in result_df.columns:
    result_df['R1 parts'] = None
if 'Acyl Formula' not in result_df.columns:
    result_df['Acyl Formula'] = None

# Save the results to a new Excel file
result_df.to_excel(output_path1, index=False)