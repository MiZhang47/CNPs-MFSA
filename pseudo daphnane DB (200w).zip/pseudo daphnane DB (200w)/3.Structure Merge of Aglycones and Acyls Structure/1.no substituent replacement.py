import os
import pandas as pd

# input and output files
input_path1 = os.path.join('C:/Users/zhang/Desktop/Structure/', 'MD_5Re_18_7d_20_6d_5d.xlsx')
output_path1 = os.path.join('C:/Users/zhang/Desktop/finish/', '28.MD_5Re_18_7d_20_6d_5d.xlsx')

# Load Excel file
df = pd.read_excel(input_path1)

# Regular expression matching the string you want to delete

# patterns_to_remove = r'\(\*oned\*\)|\*three\*|\(O\*twelve\*\)|\*fourteen\*|\*twenty\*' # normal daphnane
# patterns_to_remove = r'\*twenty\*' # normal daphnane
# patterns_to_remove = r'\*twenty\*|\*twelve\*' # normal daphnane
# patterns_to_remove = r'\*oned\*|\*three\*|\*twelve\*|\*fourteen\*|\*twenty\*' # normal daphnane

patterns_to_remove = r'\*three\*|\(O\*twelve\*\)' # 18-7d-20-6d-5d
# patterns_to_remove = r'\*twenty\*|\(O\*twelve\*\)' # 18-7d-3-6d-5d
# patterns_to_remove = r'\*three\*|\(O\*twelve\*\)|\(O\*fived\*\)' # 18-7d-20-6d
# patterns_to_remove = r'\*twenty\*|\(O\*twelve\*\)|\(O\*fived\*\)' # 18-7d-3-6d
# patterns_to_remove = r'\*three\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)' # 18-7d-20
# patterns_to_remove = r'\*twenty\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)' # 18-7d-3
# patterns_to_remove = r'\(O\*twelve\*\)|O\*eighteen\*|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 3-20-12
# patterns_to_remove = r'\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 3-18-20
# patterns_to_remove = r'\*twenty\*\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 3-18-12
# patterns_to_remove = r'\*three\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 18-20
# patterns_to_remove = r'\*twenty\*|\*three\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)' # 18-7d
# patterns_to_remove = r'\*twenty\*|\*three\*|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 12-18
# patterns_to_remove = r'\(O\*twelve\*\)|O\*eighteen\*|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 3-20
# patterns_to_remove = r'\*twenty\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 3-18
# patterns_to_remove = r'\*three\*|O\*eighteen\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 20
# patterns_to_remove = r'\*twenty\*|\*three\*|\(O\*twelve\*\)|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 18
# patterns_to_remove = r'\*twenty\*|\*three\*|O\*eighteen\*|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 12
# patterns_to_remove = r'\*twenty\*|\(O\*twelve\*\)|O\*eighteen\*|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)' # 3
# patterns_to_remove = r'\(O\*twelve\*\)|O\*eighteen\*|\(O\*fived\*\)|\(O\*sixd\*\)|\(O\*sevend\*\)'
# patterns_to_remove = r'\*three\*|\*twenty\*' # macrocyclic daphnane
# patterns_to_remove = r'\*three\*|\*twelve\*|\*twenty\*|\*fived\*|\*sixd\*|\*sevend\*' # macrocyclic daphnane
# patterns_to_remove = r'\*three\*|\*twelve\*|\*eighteen\*|\*fived\*|\*sixd\*|\*sevend\*' # macrocyclic daphnane
# patterns_to_remove = r'\*twelve\*|\*twenty\*|\*eighteen\*|\*fived\*|\*sixd\*|\*sevend\*' # macrocyclic
# daphnane
# patterns_to_remove = r'\*three\*|\*twenty\*|\*eighteen\*|\*fived\*|\*sixd\*|\*sevend\*' # macrocyclic
# daphnane

# Use regular expressions to delete the specified string pattern
df['New SMILES'] = df['New SMILES'].str.replace(patterns_to_remove, '', regex=True)

# Save the modified DataFrame to a new Excel file
df.to_excel(output_path1, index=False)