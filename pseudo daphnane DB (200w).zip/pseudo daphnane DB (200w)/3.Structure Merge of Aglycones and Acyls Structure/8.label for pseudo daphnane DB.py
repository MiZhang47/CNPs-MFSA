import os
import pandas as pd

# Set the folder path
folder_path = 'C:/Users/zhang/Desktop/new/'

# Get all .xlsx files and sort them by the numeric prefix in the filename
files = sorted(
    [f for f in os.listdir(folder_path) if f.endswith('.xlsx')],
    key=lambda x: int(x.split('.')[0])
)

# Starting number
start_number = 1196981

# Iterate over each file
for filename in files:
    input_path = os.path.join(folder_path, filename)

    # Read the Excel file
    df = pd.read_excel(input_path)

    # Get the number of rows (how many new IDs are needed)
    count = len(df)

    # Generate a new sequence of IDs
    new_numbers = [f"PD{str(start_number + i).zfill(8)}" for i in range(count)]
    df['Number'] = new_numbers

    # Get the minimum and maximum ID for the current file
    min_id = new_numbers[0]
    max_id = new_numbers[-1]

    # Update the starting number for the next file
    start_number += count

    # Generate the new output filename
    base_name, _ = os.path.splitext(filename)
    new_filename = f"{base_name} ({min_id}-{max_id}).xlsx"
    output_path = os.path.join(folder_path, new_filename)

    # Save the updated file
    df.to_excel(output_path, index=False)
    print(f"{filename} -> {new_filename} ✔️")