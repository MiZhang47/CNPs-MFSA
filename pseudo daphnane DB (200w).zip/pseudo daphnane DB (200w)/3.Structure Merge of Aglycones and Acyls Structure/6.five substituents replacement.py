import pandas as pd

# paths
input_path1 = 'C:/Users/zhang/Desktop/Structure/MD_4Re_18_7d_20_6d.xlsx'
input_path2 = 'C:/Users/zhang/Desktop/Structure/Acyl-MD-five substituents.xlsx'
output_path1 = 'C:/Users/zhang/Desktop/Structure/MD_5Re_18_7d_20_6d_5d.xlsx'

# Excel
df_skeleton = pd.read_excel(input_path1)
df_acyl = pd.read_excel(input_path2)

# Convert to DataFrame and save
df_skeleton_filtered = df_skeleton[df_skeleton['New SMILES'].str.contains('\*fived\*')]

result_rows = []
seen_combinations = set()

for _, skeleton_row in df_skeleton_filtered.iterrows():
    skeleton_smiles = skeleton_row['New SMILES']

    # Skeleton combination
    abcm_combination = (
    skeleton_row['A parts'], skeleton_row['B parts'], skeleton_row['C parts'], skeleton_row['Macro parts'])

    for _, acyl_row in df_acyl.iterrows():
        r1 = skeleton_row['R1 parts']
        r2 = skeleton_row['R2 parts']
        r3 = skeleton_row['R3 parts']
        r4 = skeleton_row['R4 parts']
        r5 = acyl_row['R5 parts']

        # Four substituent combinations, regardless of order
        substitution_combination = tuple(sorted([r1, r2, r3, r4, r5]))

        # Construct a complete key combination
        combination_key = (abcm_combination, substitution_combination)

        # Check if the combination already exists
        if combination_key not in seen_combinations:
            seen_combinations.add(combination_key)

            # Replace *twelve* with Acyl SMILES2
            new_smiles = skeleton_smiles.replace('*fived', acyl_row['Acyl SMILES2'])
            result_row = skeleton_row.copy()
            result_row['New SMILES'] = new_smiles
            result_row['R1 parts'] = r1
            result_row['R2 parts'] = r2
            result_row['R3 parts'] = r3
            result_row['R4 parts'] = r4
            result_row['R5 parts'] = r5
            result_row['Acyl Formula 5'] = acyl_row['Acyl Formula 5']

            result_rows.append(result_row)

# Convert to DataFrame and save
result_df = pd.DataFrame(result_rows)
result_df.to_excel(output_path1, index=False)