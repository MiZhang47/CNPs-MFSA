import pandas as pd

# paths
input_path1 = 'C:/Users/zhang/Desktop/Structure/MD_2Re_18_7d.xlsx'
input_path2 = 'C:/Users/zhang/Desktop/Structure/Acyl-MD-three substituents.xlsx'
output_path1 = 'C:/Users/zhang/Desktop/Structure/MD_3Re_18_7d_20.xlsx'

# Excel
df_skeleton = pd.read_excel(input_path1)
df_acyl = pd.read_excel(input_path2)

# Filter out rows containing only *twenty*
df_skeleton_filtered = df_skeleton[df_skeleton['New SMILES'].str.contains('\*twenty\*')]

result_rows = []
seen_combinations = set()

for _, skeleton_row in df_skeleton_filtered.iterrows():
    skeleton_smiles = skeleton_row['New SMILES']

    # Skeleton combination
    abcm_combination = (skeleton_row['A parts'], skeleton_row['B parts'], skeleton_row['C parts'], skeleton_row['Macro parts'])

    for _, acyl_row in df_acyl.iterrows():
        r1 = skeleton_row['R1 parts']
        r2 = skeleton_row['R2 parts']
        r3 = acyl_row['R3 parts']

        # Three substituent combinations, regardless of order
        substitution_combination = tuple(sorted([r1, r2, r3]))

        # Construct a complete key combination
        combination_key = (abcm_combination, substitution_combination)

        # Check if the combination already exists
        if combination_key not in seen_combinations:
            seen_combinations.add(combination_key)

            # Replace *twenty* with Acyl SMILES1
            new_smiles = skeleton_smiles.replace('*twenty*', acyl_row['Acyl SMILES1'])
            result_row = skeleton_row.copy()
            result_row['New SMILES'] = new_smiles
            result_row['R3 parts'] = r3
            result_row['Acyl Formula 3'] = acyl_row['Acyl Formula 3']

            result_rows.append(result_row)

# Convert to DataFrame and save
result_df = pd.DataFrame(result_rows)
result_df.to_excel(output_path1, index=False)