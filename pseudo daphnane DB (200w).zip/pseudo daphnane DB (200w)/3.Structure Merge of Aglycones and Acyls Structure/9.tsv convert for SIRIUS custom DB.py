import os
import pandas as pd

# Set the folder path and output file prefix
folder_path = 'C:/Users/zhang/Desktop/new/'
output_prefix = os.path.join(folder_path, 'combined_output_part')

# Get all .xlsx files and sort them by the numeric prefix in the filename
files = sorted(
    [f for f in os.listdir(folder_path) if f.endswith('.xlsx')],
    key=lambda x: int(x.split('.')[0])
)

# Initialize a list to collect data
rows = []
start_number = 1  # Starting number

# Iterate through the files and extract 'New SMILES' data
for file in files:
    file_path = os.path.join(folder_path, file)
    df = pd.read_excel(file_path)

    # Check if the 'New SMILES' column exists
    if 'New SMILES' in df.columns:
        for smile in df['New SMILES']:
            pd_id = f"PD{str(start_number).zfill(8)}"
            id_tag = f"id-{str(start_number).zfill(2)}"
            rows.append([smile, id_tag, pd_id])
            start_number += 1
    else:
        print(f"⚠️ File {file} is missing the 'New SMILES' column and has been skipped.")

# Split the collected data and save it as multiple TSV files (up to 700,000 rows per file)
chunk_size = 700000
total_chunks = (len(rows) - 1) // chunk_size + 1

for i in range(total_chunks):
    chunk = rows[i * chunk_size : (i + 1) * chunk_size]
    output_df = pd.DataFrame(chunk, columns=['SMILES', 'ID', 'PD_Number'])
    output_path = f"{output_prefix}{i+1}.tsv"
    output_df.to_csv(output_path, sep='\t', index=False)
    print(f"✅ Output file: {output_path} ({len(chunk)} rows)")

print("🎉 All files processed successfully!")