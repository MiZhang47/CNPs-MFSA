import os
import pandas as pd
import re

input_path1 = os.path.join('C:/Users/zhang/Desktop/finish/', '28.MD_5Re_18_7d_20_6d_5d.xlsx')
output_path1 = os.path.join('C:/Users/zhang/Desktop/finish/', '28.MD_5Re_18_7d_20_6d_5d-H.xlsx')

df = pd.read_excel(input_path1)

# 替换掉 '*' 和 '(*)'
df['New SMILES'] = df['New SMILES'].str.replace(r'\(\*\)|\*', '', regex=True)

df.to_excel(output_path1, index=False)