"""
Last updated: 2025/04
"""

import os
import pandas as pd
from rdkit import Chem
from rdkit.Chem import Draw
from PIL import Image, ImageDraw, ImageFont

path_csv = os.path.join('C:/Users/zhang/Desktop/', '2.MD_0Re_H (125-1420) (PD00000125-PD00001420).csv')
df = pd.read_csv(path_csv)

# Define folder for saving images
img_folder = 'C:/Users/zhang/Desktop/2.MD_0Re_H (125-1420) (PD00000125-PD00001420)/'
if not os.path.exists(img_folder):
    os.makedirs(img_folder)

# Set font for drawing number (Ensure Arial.ttf is accessible)
font_path = 'arial.ttf'  # Update path if necessary
font_size = 26
font = ImageFont.truetype(font_path, font_size)

for index, row in df.iterrows():
    number = row['Number']
    smiles = row['New SMILES']

    # Create mol file from 'New SMILES'
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        continue

    # Draw structure as PIL image
    img = Draw.MolToImage(mol, size=(600, 400), dpi=100)

    # Add number text to image
    draw = ImageDraw.Draw(img)
    text_position = (10, 10)  # Position at top-left corner
    draw.text(text_position, str(number), font=font, fill='black')

    # Save image
    img_path = os.path.join(img_folder, f'{number}.png')
    img.save(img_path)

    # Add image path to dataframe
    df.loc[index, 'Structure'] = img_path

# Save updated csv file
df.to_csv(os.path.join('C:/Users/zhang/Desktop/', '2.MD_0Re_H (125-1420) (PD00000125-PD00001420)-.csv'), index=False)